export default function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  res.status(200).json({
    ts: Date.now(),
    server: "SignalPulse API",
    region: process.env.VERCEL_REGION || "auto",
  });
}
