export default function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  if (req.method === "OPTIONS") return res.status(200).end();

  res.status(200).json({
    name: "SignalPulse API",
    version: "1.0.0",
    region: process.env.VERCEL_REGION || "auto",
    node: process.version,
  });
}
